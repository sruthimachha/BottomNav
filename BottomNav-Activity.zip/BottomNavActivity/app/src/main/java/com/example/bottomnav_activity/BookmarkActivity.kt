package com.example.bottomnav_activity

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.startActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.bottomnav_activity.R.anim.slide_in_right
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.example.bottomnav_activity.MainActivity as MainActivity1
import com.example.bottomnav_activity.finish as finish1

class BookmarkActivity : AppCompatActivity() {
    private fun gateApplicationContext() {

    }

    private fun switch(itemId: Any, any: Any) {
        BottomNavigationView()
    }

    private fun BottomNavigationView() {
        TODO("Not yet implemented")
    }

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        this.enableEdgeToEdge()
        setContentView(R.layout.activity_bookmark)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v: View, insets: WindowInsetsCompat ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

    }
}

//BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView)
//bottomNavigationView.setSelectedItemId(R.id.bottom_bookmark)
//
//bottomNavigationView.setOnItemSelectedListener(item->: Boolean : Boolean : Boolean : Boolean {
//    val item = null
//    switch (item.getItemId(), any = fun(): Any {
//        val case = null
//        val value = case R . id . bottom_news :
//        val new = null
//        startActivity(/* context = */ new Intent (gateApplicationContext(), /* intent = */
//            MainActivity1.class))
//        overridePendingTransition(
//            slideInRight = slide_in_right,
//            slideOutLeft = R.anim.slide_out_left
//        )
//        finish()
//
//        return true
//        case R . id . bottom_bookmark :
//        return true
//    })
//    return false
//})