package com.example.bottomnav_activity

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.core.content.ContextCompat.startActivity
import com.example.bottomnav_activity.ui.theme.BottomNavActivityTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BottomNavActivityTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Greeting(
                        name = "Android",
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }

    }
}

//BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
//bottomNavigationView.setSelectedItemId(R.id.bottom_news);
//
//bottomNavigationView.setOnItemSelectedListener(item->: Boolean : Boolean
//fun switch(itemId: Any, any: Any) {
//    TODO("Not yet implemented")
//}
//
//fun gateApplicationContext(): Any {
//
//}
//
//fun overridePendingTransition(slideInRight: Int, slideOutLeft: Int) {
//    TODO("Not yet implemented")
//}
//
//fun finish() {
//    TODO("Not yet implemented")
//}
//
//: Boolean : Boolean : Boolean {
//    val item = null
//    switch (item.getItemId()){
//        val case = null
//        case R.id.bottom_newspaper:
//        return@switch true;
//        case R.id.bottom_bookmark:
//        startActivity(new Intent(gateApplicationContext(),BookmarkActivity.class));
//        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
//        finish()
//        return@switch true;
//    }
//    return false:
//});

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    BottomNavActivityTheme {
        Greeting("Android")
    }
}